﻿using Consoleapp.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Consoleapp
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            ServiceClient client = new ServiceClient();

            try
            {
                // Taking first number input
                Console.Write("Enter the first number: ");
                int num1 = int.Parse(Console.ReadLine());

                // Taking second number input
                Console.Write("Enter the second number: ");
                int num2 = int.Parse(Console.ReadLine());

                // Taking operation input
                Console.Write("Enter an operation (+, -, *, /): ");
                char operation = char.Parse(Console.ReadLine());
                Console.WriteLine();  // For formatting purposes

                int result = 0;

                // Using switch to perform the selected operation
                switch (operation)
                {
                    case '+':
                        result = await client.AdditionAsync(num1, num2);
                        Console.WriteLine($"the result is {result}");
                            break;
                    case '-':
                        result = await client.SubtractionAsync(num1, num2);
                        Console.WriteLine($"the result is {result}"); break;
                    case '*':
                        result = await client.MultiplicationAsync(num1, num2);
                        Console.WriteLine($"the result is {result}"); break;
                    case '/':
                        result = await client.DivisionAsync(num1, num2);
                        Console.WriteLine($"the result is {result}");
                        break;
                    default:
                        Console.WriteLine("Error: Invalid operation.");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error has occured. Try again later!");
            }
        }
    }
}

