﻿using System;
using CalculatorWebApp.CaclulatorService;
  // Import the service reference

namespace CalculatorWebApp
{
    public partial class Default : System.Web.UI.Page
    {
        protected void ButtonAdd_Click(object sender, EventArgs e)
        {
            CalculatorSoapClient client = new CalculatorSoapClient();
            int num1 = int.Parse(TextBox1.Text);
            int num2 = int.Parse(TextBox2.Text);
            int result = client.Add(num1, num2);  // Call Add operation
            LabelResult.Text = "Result: " + result.ToString();
        }

        protected void ButtonSubtract_Click(object sender, EventArgs e)
        {
            CalculatorSoapClient client = new CalculatorSoapClient();
            int num1 = int.Parse(TextBox1.Text);
            int num2 = int.Parse(TextBox2.Text);
            int result = client.Subtract(num1, num2);  // Call Subtract operation
            LabelResult.Text = "Result: " + result.ToString();
        }

        protected void ButtonMultiply_Click(object sender, EventArgs e)
        {
            CalculatorSoapClient client = new CalculatorSoapClient();
            int num1 = int.Parse(TextBox1.Text);
            int num2 = int.Parse(TextBox2.Text);
            int result = client.Multiply(num1, num2);  // Call Multiply operation
            LabelResult.Text = "Result: " + result.ToString();
        }

        protected void ButtonDivide_Click(object sender, EventArgs e)
        {
            CalculatorSoapClient client = new CalculatorSoapClient();
            int num1 = int.Parse(TextBox1.Text);
            int num2 = int.Parse(TextBox2.Text);
            int result = client.Divide(num1, num2);  // Call Divide operation
            LabelResult.Text = "Result: " + result.ToString();
        }
    }
}
